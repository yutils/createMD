#  MYSQL安装失败

提示  
MySQL error 1042: Unable to connect to any of the specified MySQL hosts.  
Failed to connect to MySQL Server 8.0.19 after 10 attempts.  
Ended configuration step: Starting the server   

![01](images/01.png)  

解决办法  

![02](images/02.png)  
