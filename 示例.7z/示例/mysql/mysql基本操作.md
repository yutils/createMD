## 初始化
### 1、卸载、删除之前安装的MySQL
net stop mysql80  
mysqld --remove mysql  
mysqld --remove mysql80  

### 2、初始化设置
mysqld --initialize-insecure --user=mysql
### 3、创建服务
mysqld --install mysql80
### 4、启动服务
net start mysql80
### 5、登录mysql，密码直接敲回车 （docker直接第5步开始）  
mysql -uroot -p
### 6、修改密码（docker已经有密码，跳过）
alter user'root'@'localhost' IDENTIFIED BY 'wtugeqh';

alter user'root'@'%' IDENTIFIED BY 'cdhn@103';

alter user'root'@'localhost' IDENTIFIED BY 'cdhn@103';

### 7、修改时区
set global time_zone = '+8:00';show variables like'%time_zone';
### 8、创建一个yujing-wtugeqh用户
```sql
#废弃
CREATE USER 'yujing'@'%' IDENTIFIED BY 'wtugeqh';
grant select,insert,update,delete,create,drop,index,alter,references,reload,shutdown,process,file on *.* to yujing;
flush  privileges;
```

### 基本命令
-   进入mysql:	mysql -uroot -pwtugeqh
-   进入mysql:	mysql -u账号 -p密码 -h地址 -P端口			如：mysql -uroot -pwtugeqh -hlocalhost -P3306
-   全部数据库:	show databases;
-   进入数据库:	use mysql;
-   显示全部表:	show tables;
-   SQL查询:		select host,user,password from mysql.user;
-   mysql查看端口:	show global variables like 'port';
-   安装mysql:	apt-get install mysql-server mysql-client
-   启动mysql:	sudo /etc/init.d/mysql start
-   重启MySQL:	sudo /etc/init.d/mysql restart;
-   卸载mysql:	apt-get remove mysql-server

### 创建数据库  
CREATE DATABASE IF NOT EXISTS 名称 DEFAULT CHARSET utf8 COLLATE utf8_general_ci;  
**创建用户，以下3步:	**  
1.创建：	CREATE USER '用户名'@'%' IDENTIFIED BY '密码';  
2.授权:*代表整个数据库：	grant select,insert,update,delete,create,drop on [数据库名称].* to [用户名称];  
3.生效：	flush  privileges;  
**创建一个yujing-wtugeqh用户，使得远程可以访问，执行以下4条语句**  

```sql
CREATE USER 'yujing'@'%' IDENTIFIED BY 'wtugeqh';
grant all privileges on *.* to yujing;
flush  privileges;
UPDATE `mysql`.`user` SET `Grant_priv` = 'Y' WHERE `User` = 'yujing';
flush  privileges;
```
**删除用户 **  

```sql
delete from mysql.user where user='yujing';flush  privileges;
```
修改root用户作用域  
```sql
UPDATE mysql.user SET Host = '%' WHERE User = 'root';flush  privileges;  
```
**修改密码:**  
格式：	mysql> set password for 用户名@localhost = password('新密码');  
举例：	mysql> set password for root@'%' = password('123');   
如果MySQL8.0连接不上，指定身份验证方式，或者直接改为以前的版本方式，这儿把yujing的密码改成了wtugeqh：  
//旧加密方式  
ALTER USER 'yujing'@'%' IDENTIFIED WITH mysql_native_password BY 'wtugeqh';flush  privileges;  
//新加密方式  
ALTER USER 'yujing'@'%' IDENTIFIED WITH caching_sha2_password BY 'wtugeqh';flush  privileges;  

### MYSQL常用操作
**1. 忘记root密码**  
编辑mysql主配置文件 my.cnf 在[mysqld]字段下添加参数  skip-grant  ,  
重启数据库服务,这样就可以进入数据库不用授权了 mysql -uroot ,  
修改相应用户密码 use mysql; update user set password=password('your password') where user='root';flush privileges;  
最后修改/etc/my.cnf 去掉 skip-grant , 重启mysql服务  
**2. skip-innodb   我们可以增加这个参数不使用innodb引擎。**  
**3. 配置慢查询日志**  

- #log_slow_queries = /path/to/slow_queries  
- #long_query_time = 1  

**4. mysql常用操作**  
- 登陆mysql方法，可以用IP或者socket  
IP：mysql -uroot -p123456 -h127.0.0.1 -P3306        #-P 是mysql监听端口  
socket : mysql -uroot -p123456 -S /tmp/mysql.socket     #-S 是socket的路径  

- 查看都有哪些库 **show databases;**  
- 进入某个库 **use db;**  
- 查看库里有哪些表 ** show tables; **  
- 查看表的字段 **desc tb;**  
- 查看建表语句 **show create table tb;**  
- 查看当前是哪个用户  **select user();**  
- 查看当前库 **select database();**  
- 创建库 **create database db1; **  
- 创建表 **create table t1 (`id` int(4), `name` char(40));  **  
- 填写表 **insert into tb1 (id,name) values(1,'aming');**  
- 查看表的内容 **select * from tb;**  
- 查看数据库版本 **select version(); **  
- 查看mysql状态 **show status;**  
- 修改mysql参数 **show variables like 'max_connect%'; set global max_connect_errors = 1000;  ** //百分号%表示通配符; set global 是在不重启mysql情况下修改配置，重启后会恢复，永久生效改my.cnf    
- 查看mysql队列 **show processlist; **  
- 创建普通用户并授权，同时设置密码  
```sql
grant all on *.* to user1 identified by '123456'; 
grant all on db1.* to 'user2'@'10.0.2.100' identified by '111222'; 
grant all on db1.* to 'user3'@'%' identified by '231222';
```
- 更改密码 **update mysql.user set password=password("newpwd") where user='username' ; flush privileges;**        #修改密码后要刷新  
- 查询 **select count(*) from mysql.user; select * from mysql.db; select * from mysql.db where host like '10.0.%'; **  
- 插入 **update db1.t1 set name='aaa' where id=1;  **  
- 清空表 **truncate table db1.t1; **  
- 删除表 **drop table db1.t1; **  
- 删除数据库 **drop database db1; **  
- 修复表 **repair table tb1 [use_frm];**  

**5. mysql备份与恢复**  

- 备份 **mysqldump -uroot -p123456 db >1.sql **  
- 恢复 **mysql -uroot -p123456 db  2.sql**  
- 只备份建表语句 **mysqldump -uroot -p123456 -d db tb1 > 2.sql**  
- 备份时指定字符集 **mysqldump -uroot -p --default-character-set=utf8  db >1.sql**  
- 恢复也指定字符集 **mysql -uroot -p --default-character-set=utf8  db  < 1.sql**  