# JDBC连接限制了最大包长度1024B
java.lang.RuntimeException: org.apache.cxf.interceptor.Fault: Packet for query is too large (1917 > 1024). You can change this value on the server by setting the max_allowed_packet' variable.  
主要是mysql的JDBC连接限制了最大包长度1024B，即1KB。  
![03](images/03.png)  
**解决方案：查询分析器输入这几句话运行。**  
set global max_allowed_packet = 100*1024*10  
重启mysql，检查运行是否成功  
show variables like '%max_allowed_packet%'   
**如果没生效：**  
C:\ProgramData\MySQL\MySQL Server 5.7\my.ini   
修改274行左右：max_allowed_packet=100M  
重启mysql，检查运行是否成功  
show variables like '%max_allowed_packet%'   