# 在 Linux 虚拟机中手动安装或升级 VMware Tools

更新时间2019年05月31日

对于 Linux 虚拟机，您可以使用命令行工具手动安装或升级 VMware Tools。

## 前提条件

- 开启虚拟机。
- 确认客户机操作系统正在运行。
- 由于 VMware Tools 安装程序是使用 Perl 编写的，因此，请确认在客户机操作系统中安装了 Perl。

## 过程

1. 在主机上，从 Workstation Pro 菜单栏中选择**虚拟机** > **安装 VMware Tools**。

   如果安装了早期版本的 VMware Tools，则菜单项是 **更新 VMware Tools**。

2. 在虚拟机中，以 root 身份登录到客户机操作系统并打开终端窗口。

3. 不带参数运行 mount 命令以确定 Linux 发行版是否自动装载 VMware Tools 虚拟 CD-ROM 映像。

   如果装载了 CD-ROM 设备，将按以下方式列出 CD-ROM 设备及其装载点：

   ```shell
   /dev/cdrom on /mnt/cdrom type iso9660 (ro,nosuid,nodev)
   ```

4. 如果未装载 VMware Tools 虚拟 CD-ROM 映像，请装载 CD-ROM 驱动器。

   1. 如果装载点目录尚不存在，请创建该目录。

      ```shell
      mkdir /mnt/cdrom
      ```

      某些 Linux 发行版使用不同的装载点名称。例如，某些发行版上的装载点是 /media/VMware Tools 而不是 /mnt/cdrom。请修改该命令以反映您的发行版使用的约定。

   2. 装载 CD-ROM 驱动器。

      ```shell
      mount /dev/cdrom /mnt/cdrom
      ```

      某些 Linux 发行版使用不同的设备名称，或者以不同的方式组织 /dev 目录。如果 CD-ROM 驱动器不是 /dev/cdrom 或 CD-ROM 装载点不是 /mnt/cdrom，则必须修改该命令以反映您的发行版使用的约定。

5. 转到工作目录，例如 /tmp。

   `cd /tmp`

6. 在安装 VMware Tools 之前，删除以前的 vmware-tools-distrib 目录。

   该目录的位置取决于以前安装时的存储位置。通常，该目录位于 /tmp/vmware-tools-distrib。

7. 列出装载点目录的内容，并记下 VMware Tools tar 安装程序的文件名。

   ```shell
   ls mount-point
   ```

8. 解压缩安装程序。

   ```shell
   cd /tmp/
   tar zxpf /mnt/cdrom/VMwareTools-x.x.x-yyyy.tar.gz
   cd vmware-tools-distrib/
   ```

   x.x.x 值是产品版本号，yyyy 是产品版本的内部版本号。

   如果尝试安装 tar 安装以覆盖 RPM 安装或相反，安装程序将检测以前的安装并且必须转换安装程序数据库格式，然后才能继续操作。

9. 如果需要，请卸载 CD-ROM 映像。

   ```shell
   umount /dev/cdrom 
   ```

   如果 Linux 发行版自动装载 CD-ROM，则不需要卸载该映像。

10. 运行安装程序并配置 VMware Tools。

    ```shell
    cd vmware-tools-distrib
    #必须用sudo
    sudo ./vmware-install.pl
    ```

    通常，在安装程序文件结束运行后，将运行 vmware-config-tools.pl 配置文件。

11. 如果适合您的配置，请按照提示接受默认值。

12. 按照脚本结尾处的说明进行操作。

    根据使用的功能，这些说明可能包括重新启动 X 将话、重新启动网络连接、重新登录以及启动 VMware 用户进程。或者，也可以重新引导客户机操作系统以完成所有这些任务。