# Debian11 搭建ProxmoxVE

```shell
vi /etc/hosts
#如果您的 IP 地址是192.168.6.65，并且您的主机名是debian，那么您的/etc/hosts文件可能如下所示：
```
```
127.0.0.1       localhost
192.168.15.77   debian.proxmox.com debian
# The following lines are desirable for IPv6 capable hosts
::1     localhost ip6-localhost ip6-loopback
ff02::1 ip6-allnodes
ff02::2 ip6-allrouters
```

```shell
#可以使用hostname命令测试您的设置是否正常：
hostname --ip-address
192.168.6.65 # 应该返回IP地址
```


```shell
# 更新系统
apt update -y && apt upgrade -y

#或者使用国内镜像
sudo echo "deb [arch=amd64] https://mirrors.tuna.tsinghua.edu.cn/proxmox/debian bullseye pve-no-subscription" > /etc/apt/sources.list.d/pve-install-repo.list
#添加 Proxmox VE 的软件源
sudo echo "deb [arch=amd64] http://download.proxmox.com/debian/pve bullseye pve-no-subscription" > /etc/apt/sources.list.d/pve-install-repo.list

#添加密钥
wget https://enterprise.proxmox.com/debian/proxmox-release-bullseye.gpg -O /etc/apt/trusted.gpg.d/proxmox-release-bullseye.gpg
#验证密钥： sha512sum /etc/apt/trusted.gpg.d/proxmox-release-bullseye.gpg

#更新
apt update && apt full-upgrade

#安装Proxmox VE软件包
apt install proxmox-ve postfix open-iscsi
#如果提示：下列软件包有未满足的依赖关系
#则执行： apt install aptitude && aptitude install proxmox-ve postfix open-iscsi

#配置postfix，选择Internet Site，其他配置选择默认。
#sudo dpkg-reconfigure postfix

```

### 安装完成后 重新启动系统

```shell
#如果您没有将Proxmox VE安装为另一个操作系统旁边的双引导，您可以安全地删除os prober包。
apt remove os-prober
```



### 连接到管理 Web 界面 (https://192.168.6.65:8006)。

如果你是全新安装并且还没有添加任何用户，你应该使用 root 帐户和你的 linux root 密码，并选择“PAM Authentication”登录。

创建一个 Linux 桥
登录后，创建一个名为vmbr0的Linux Bridge，并将您的第一个网络接口添加到它。

![wq](images/wq.png)
