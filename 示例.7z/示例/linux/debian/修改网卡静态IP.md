# 修改网卡静态IP

```shell
cd /etc/network
nano interfaces
```

**列：配置网卡 eth12345**

在 interfaces添加 

```
iface eth12345 inet static
 address 10.1.1.5
 netmask 255.255.255.0
 gateway 10.1.1.1
```



使用`Ctrl + O`组合键保存网卡配置文件内容

使用`Ctrl + X`组合键退出nano编辑器。

使用`cat interfaces`命令查看已修改的网卡配置文件的内容。

使用`/etc/init.d/networking restart`命令使用网卡配置文件内容生效，

使用`ip a`查看网卡信息

