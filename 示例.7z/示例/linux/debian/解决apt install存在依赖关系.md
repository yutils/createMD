# 解决apt install存在依赖关系导致无法安装成功的办法

安装aptitude，使用aptitude进行安装会自动给出解决方案  
```shell
apt install aptitude
aptitude install XXX
```

