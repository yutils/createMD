# apt-get 更改源

## 查看所用的源
```shell
sudo vim /etc/apt/sources.list
```
为了提高下载速度，将源改为国内的 cn.archive.ubuntu.com ，现在 cn.archive.ubuntu.com 指向阿里云的开源镜像站 mirrors.aliyun.com，下载速度很快。  

## 1. 复制源作为备份
```shell
#备份
sudo cp /etc/apt/sources.list /etc/apt/sources.list.bak
#还原
sudo cp /etc/apt/sources.list.bak /etc/apt/sources.list
#删除
sudo rm /etc/apt/sources.list
```
## 2. 新建一个sources.list文件
```shell
sudo vim /etc/apt/sources.list
```
输入如下内容并保存退出  
```shell
deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb http://security.debian.org/debian-security bullseye-security main
deb-src http://security.debian.org/debian-security bullseye-security main
deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main

#或者输入
echo 'deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb http://security.debian.org/debian-security bullseye-security main
deb-src http://security.debian.org/debian-security bullseye-security main
deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main' >> /etc/apt/sources.list

#或者输入
cat >> /etc/apt/sources.list << EOF
deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye main
deb http://security.debian.org/debian-security bullseye-security main
deb-src http://security.debian.org/debian-security bullseye-security main
deb http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main
deb-src http://mirrors.tuna.tsinghua.edu.cn/debian/ bullseye-updates main
EOF
```

## 3. 更新apt软件源：
```shell
apt update -y && apt upgrade -y 
```
