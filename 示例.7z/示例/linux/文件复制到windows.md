## 文件复制到windows
### 1. 服务器到本地
```shell
# 给文件权限
chmod 777 openvpn-backup.tar
# windows安装putty后用cmd运行
pscp -C yujing@192.168.6.113:/home/yujing/openvpn-backup.tar C:\Users\yujing\Desktop
```
### 2. 本地到服务器
```shell
pscp -C C:\Users\yujing\Desktop\openvpn-backup.tar cdhn@192.168.1.85:/home/cdhn
```