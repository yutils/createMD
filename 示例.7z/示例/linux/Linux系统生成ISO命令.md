# Linux系统生成ISO命令


示例：  
```shell
#安装
apt install genisoimage
#显示的是支持的编码列表
genisoimage -input-charset -help 
#把当前目录下的yujing文件夹生成yujing.iso，并且光盘名称叫做余静的光盘
#或者
genisoimage --input-charset utf-8 -r -l  -T -J -V "余静的光盘" -o yujing.iso yujing/
#如：
genisoimage --input-charset utf-8 -r -l  -T -J -V "2022年" -o 2022年.iso 2022年/
```

说明  

genisoimage与mkisofs为同一个命令，执行mkisofs最终调用的为genisoimage命令

语法  

```
genisoimage [-adDfhJlLNrRTvz][-print-size][-quiet][-A <应用程序ID>][-abstract <摘要文件>][-b <开机映像文件>][-biblio <ISBN文件>][-c <开机文件名称>][-C <盘区编号，磁区编号>][-copyright <版权信息文件>][-hide <目录或文件名>][-hide-joliet <文件或目录名>][-log-file <记录文件>][-m <目录或文件名>][-M <开机映像文件>][-o <映像文件>][-p <数据处理人>][-P <光盘发行人>][-sysid <系统ID >][-V <光盘ID >][-volset <卷册集ID>][-volset-size <光盘总数>][-volset-seqno <卷册序号>][-x <目录>][目录或文件]
```


| 参数                                                | 使用详解                                                     |
| --------------------------------------------------- | ------------------------------------------------------------ |
| -a或–all                                            | mkisofs默认不处理备份文件。使用此参数可以将备份文件加到镜像文件中 |
| -A <应用程序ID>或–appid  <应用程序ID>               | 指定光盘的应用程序ID                                         |
| -abstract <摘要文件>                                | 指定摘要文件名                                               |
| -b  <开机映像文件>或者-eltorito-boot <开机映像文件> | 指定在制作开机光盘时所需的开机镜像文件                       |
| -biblio <ISBN文件>                                  | 指定ISBN文件的文件名，ISBN在光盘的根目录下，记录光盘的ISBN   |
| -c <开机文件名称>                                   | 在制作开机光盘时，mkisofs会将开机镜像文件中的-eltorito-catalog  <开机文件名称>全部内容做成一个文件 |
| -C <盘区编号，盘区编号>                             | 将许多节区合成一个镜像文件时，必须使用该参数                 |
| -copyright <版权信息文件>                           | 指定版权信息文件名                                           |
| -d或-omit-period                                    | 省略文件名后的句号                                           |
| -D或-disable-deep-relocation                        | ISO 9600最多只能处理8层的目录，超过8层的目录，RRIP会默认将其设置为ISO  9600兼容的格式，使用该参数可以关闭该功能 |
| -f或-follow-link                                    | 忽略符号链接                                                 |
| -h                                                  | 显示帮助                                                     |
| -hide <目录或者文件名>                              | 使指定的目录或者文件名在ISO 9660或者Rock RidgeExtensions格式中隐藏 |
| -hide-joliet <目录或者文件名>                       | 指定的文件或者目录在Joliet系统中隐藏                         |
| -J或-joliet                                         | 使用Joliet格式的目录或者文件名称                             |
| -l或-full-iso9600-filenames                         | 使用ISO 9600 32字符长度的文件名                              |
| -L或-allow-leading-dots                             | 允许文件名的第一个字符为句号                                 |
| -log-file <记录文件>                                | 在执行过程中若有报错信息，预设会显示在屏幕上                 |
| -m <目录或者文件名>或-exclude  <目录或者文件名>     | 指定的目录或者文件不会放入镜像中                             |
| -M <镜像文件>或-prev-session  <镜像文件>            | 与指定的镜像文件合并                                         |
| -N或-omit-version-number                            | 省略ISO 9600文件中的版本信息                                 |
| -o <镜像文件>或-output  <镜像文件>                  | 指定镜像文件的名称                                           |
| -p <数据处理人>或-reparer  <数据处理人>             | 记录数据处理人                                               |
| -print-size                                         | 显示预估的文件系统大小                                       |
| -quiet                                              | 执行时不显示任何信息                                         |
| -r或-rational-rock                                  | 使用Rock Ridge Extensions，并开放所有的文件读取权限          |
| -R或-rock                                           | 使用Rock Ridge Extensions                                    |
| -sysid <系统ID>                                     | 指定光盘系统ID                                               |
| -T或-translation-table                              | 建立文件名的转换表，适用于不支持Rock Ridge Extensions的系统  |
| -v或-verbose                                        | 执行时显示详细的信息                                         |
| -V <光盘ID>或-volid  <光盘ID>                       | 指定光盘的卷册集ID                                           |
| -volset-size <光盘总数>                             | 指定卷册集所包含的光盘总数                                   |
| -volset-seqno <卷册序号>                            | 指定光盘片在卷册集中的编号                                   |
| -x <目录>                                           | 指定的目录不会放入到镜像中                                   |
| -z                                                  | 建立通透性压缩文件的SUSP记录，此记录只在Alpha机器的Linux系统上有效 |

```

 
Usage: genisoimage [options] file...
Options:
 
  -nobak                      不要包含备份文件
 
  -no-bak                     不要包含备份文件
 
  -abstract FILE              设置抽象文件名
 
  -A ID, -appid ID            设置应用程序ID
 
  -biblio FILE                设置书目文件名
 
  -cache-inodes               缓存inode（需要检测硬链接）
 
  -no-cache-inodes            不要缓存inode（如果文件系统没有唯一的单元）
 
  -check-oldnames            从旧会话中检查所有导入的ISO9660名称
 
  -check-session FILE         检查以前会话中的所有ISO9660名称
 
  -copyright FILE             设置版权文件名
 
  -debug                      设置调试标志
 
  -b FILE, -eltorito-boot FILE
 
                              设置El Torito启动映像名称
 
  -eltorito-alt-boot          开始指定替代El Torito引导参数
 
  -B FILES, -sparc-boot FILES 设置sparc启动映像名称
 
  -sunx86-boot FILES          设置sunx86启动映像名称
 
  -G FILE, -generic-boot FILE 设置通用引导映像名称
 
  -sparc-label label text     设置sparc启动磁盘标签
 
  -sunx86-label label text    设置sunx86启动磁盘标签
 
  -c FILE, -eltorito-catalog FILE
 
                              设置El Torito引导目录名称
 
  -C PARAMS, -cdrecord-params PARAMS 来自cdrecord的魔术参数
 
  -d, -omit-period            忽略来自文件名的尾随句点（违反ISO9660）
 
  -dir-mode mode              使所有目录的模式成为此模式。
 
  -D, -disable-deep-relocation 禁用深度目录重定位（违反ISO9660）
 
  -file-mode mode             使所有普通文件的模式成为此模式。
 
  -f, -follow-links           跟随符号链接
 
  -gid gid                    让所有文件的群组拥有者成为这个gif。
 
  -graft-points               允许使用嫁接点作为文件名
 
  -root DIR                   为所有新文件和目录设置根目录
 
  -old-root DIR               在前一个搜索文件的会话中设置根目录
 
  -help                       打印选项帮助
 
  -hide GLOBFILE              隐藏ISO9660 / RR文件
 
  -hide-list FILE             带有ISO9660 / RR文件列表的文件要隐藏
 
  -hidden GLOBFILE            在ISO9660文件上设置隐藏属性
 
  -hidden-list FILE           带有隐藏属性的ISO9660文件列表文件
 
  -hide-joliet GLOBFILE       隐藏Joliet文件
 
  -hide-joliet-list FILE      带有Joliet文件列表的文件要隐藏
 
  -hide-joliet-trans-tbl      从Joliet树隐藏TRANS.TBL
 
  -hide-rr-moved              在Rock Ridge树中将RR_MOVED重命名为.rr_moved
 
  -gui                                切换GUI的行为
 
  -i ADD_FILES                  不再支持
 
  -input-charset CHARSET      用于文件名转换的本地输入字符集
 
  -output-charset CHARSET     输出文件名转换字符集
 
  -iso-level LEVEL            为ISO9660版本2设置ISO9660一致性等级（1..3）或4
 
  -J, -joliet                 生成Joliet目录信息
 
  -joliet-long                允许Joliet文件名为103个Unicode字符
 
  -jcharset CHARSET           Joliet目录信息的本地字符集
 
  -l, -full-iso9660-filenames ISO9660名称允许完整的31个字符文件名
 
  -max-iso9660-filenames      允许ISO9660名称的37个字符文件名（违反ISO9660）
 
  -allow-leading-dots         允许ISO9660文件名以'。'开头。 （违反ISO9660）
 
  -ldots                      允许ISO9660文件名以'。'开头。 （违反ISO9660）
 
  -L, -allow-leading-dots     OLD Pre-POSIX.1-2001选项 - 不要使用-L
 
  -log-file LOG_FILE          将消息重定向到LOG_FILE
 
  -m GLOBFILE, -exclude GLOBFILE 排除文件名称
 
  -exclude-list FILE          带有要排除的文件名列表的文件
 
  -pad                        填充输出到32k的倍数（默认）
 
  -no-pad                     不要将输出填充到32k的倍数
 
  -M FILE, -prev-session FILE 将路径设置为前一个会话进行合并
 
  -dev SCSIdev                将路径设置为前一个会话进行合并
 
  -N, -omit-version-number    忽略ISO9660文件名的版本号（违反ISO9660）
 
  -new-dir-mode mode          创建新目录时使用的模式。
 
  -force-rr                   禁止先前会话的自动Rock Ridge检测
 
  -no-rr                      禁止从以前的会话中读取Rock Ridge属性
 
  -no-split-symlink-components 禁止拆分符号链接组件
 
  -no-split-symlink-fields    禁止拆分符号链接字段
 
  -o FILE, -output FILE       设置输出文件名称
 
  -path-list FILE             带有要处理的路径名列表的文件
 
  -p PREP, -preparer PREP     设置音量准备
 
  -print-size                 打印估计的文件系统大小并退出
 
  -publisher PUB              设置卷发布者
 
  -P PUB, -publisher PUB      OLD Pre-POSIX.1-2001选项 - 不要使用-P
 
  -quiet                      安静地运行
 
  -r, -rational-rock          生成合理化的Rock Ridge目录信息
 
  -R, -rock                   生成Rock Ridge目录信息
 
  -s TYPE, -sectype TYPE      将输出扇区类型设置为数据/ XA1/生
 
  -sort FILE                  根据FILE中的规则对文件内容位置进行排序
 
  -split-output               将输出分割成约。 1GB大小
 
  -stream-file-name FILE_NAME 设置流文件ISO9660名称（包括版本）
 
  -stream-media-size #        在扇区中设置CD媒体的大小
 
  -sysid ID                   设置系统ID
 
  -T, -translation-table      为不了解长文件名的系统生成翻译表
 
  -table-name TABLE_NAME      翻译表文件名
 
  -ucs-level LEVEL            设置Joliet UCS等级（1..3）
 
  -udf                        生成UDF文件系统
 
  -dvd-video                  生成符合DVD-Video的UDF文件系统
 
  -uid uid                    让所有这些文件的所有者。
 
  -U, -untranslated-filenames 允许未翻译的文件名（用于HPUX和AIX - 违反ISO9660）。 Forces -l，-d，-N，-allow-leading-dots，-laxable-filename，-allow-lowercase，-allow-multidot
 
  -relaxed-filenames          允许7位ASCII，小写字符除外（违反ISO9660）
 
  -no-iso-translate           不要翻译非法ISO字符'〜'，' - '和'＃'（违反ISO9660）
 
  -allow-lowercase            除了当前字符集外，还允许使用小写字符（违反ISO9660）
 
  -allow-multidot             允许多个点的文件名（例如.tar.gz）（违反ISO9660）
 
  -use-fileversion LEVEL      使用文件系统的文件版本号
 
  -v, -verbose                详细信息
 
  -version                     显示版本
 
  -V ID, -volid ID            设置卷ID
 
  -volset ID                  设置音量设置ID
 
  -volset-size #              设置卷大小
 
  -volset-seqno #             设置卷序列号
 
  -x FILE, -old-exclude FILE  排除文件名（不建议使用）
 
  -hard-disk-boot             引导映像是硬盘映像
 
  -no-emul-boot               启动映像是“无模拟”映像
 
  -no-boot                    启动映像不可启动
 
  -boot-load-seg #            设置启动映像的加载段
 
  -boot-load-size #           设置负载扇区的数量
 
  -boot-info-table            用信息表修补引导映像
 
  -XA                         生成XA目录属性
 
  -xa                         生成合理化目录属性
 
  -z, -transparent-compression 启用文件的透明压缩
 
  -hfs-type TYPE              设置HFS默认的TYPE
 
  -hfs-creator CREATOR        设置HFS默认CREATOR
 
  -g, -apple                  添加Apple ISO9660扩展
 
  -h, -hfs                    创建ISO9660/HFS混合卷
 
  -map MAPPING_FILE           将文件扩展名映射到HFS TYPE / CREATOR
 
  -H MAPPING_FILE, -map MAPPING_FILE   OLD Pre-POSIX.1-2001选项 - 不要使用-H
 
  -magic FILE                 HFS TYPE / CREATOR的魔术文件
 
  -probe                     探测Apple / Unix文件类型的所有文件
 
  -mac-name                   为ISO9660 / Joliet / RockRidge文件名使用Macintosh名称
 
  -no-mac-files               不要查找Unix / Mac文件（不建议使用）
 
  -boot-hfs-file FILE         设置HFS启动映像名称
 
  -part                       生成HFS分区表
 
  -cluster-size SIZE          PC Exchange Macintosh文件的群集大小
 
  -auto FILE                  设置HFS AutoStart文件名称
 
  -no-desktop                 不要创建HFS（空）桌面文件
 
  -hide-hfs GLOBFILE          隐藏HFS文件
 
  -hide-hfs-list FILE         要隐藏的HFS文件的列表
 
  -hfs-volid HFS_VOLID        HFS分区的卷名称
 
  -icon-position              保持HFS图标位置
 
  -root-info FILE             用于根文件夹的finderinfo
 
  -input-hfs-charset CHARSET  用于HFS文件名转换的本地输入字符集
 
  -output-hfs-charset CHARSET 用于HFS文件名转换的输出字符集
 
  -hfs-unlock                 保持HFS卷被解锁
 
  -hfs-bless FOLDER_NAME      祝福的文件夹名称
 
  -hfs-parms PARAMETERS       以逗号分隔的HFS参数列表
 
  -prep-boot FILE             PReP启动映像文件 - 最多允许4个
 
  -chrp-boot                  添加CHRP引导标题
 
  --cap                       查找AUFS CAP Macintosh文件
 
  --netatalk                  查找NETATALK Macintosh文件
 
  --double                    查找AppleDouble Macintosh文件
 
  --ethershare                寻找Helios EtherShare Macintosh文件
 
  --exchange                  查找PC Exchange Macintosh文件
 
  --sgi                       查找SGI Macintosh文件
 
  --macbin                    查找MacBinary Macintosh文件
 
  --single                    查找AppleSingle Macintosh文件
 
  --ushare                    查找IPT UShare Macintosh文件
 
  --xinet                     寻找XINET Macintosh文件
 
  --dave                      寻找DAVE Macintosh文件
 
  --sfm                       查找SFM Macintosh文件
 
  --osx-double                查找MacOS X AppleDouble Macintosh文件
 
  --osx-hfs                   寻找MacOS X HFS Macintosh文件
```

