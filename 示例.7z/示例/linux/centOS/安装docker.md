# 安装docker

官方文档：https://docs.docker.com/engine/install/centos/

清华大学-安装方法：https://mirrors.tuna.tsinghua.edu.cn/help/docker-ce/

## 把yum包更新到最新
```shell
yum update
```
## 卸载旧版本docker
```shell
yum -y  remove docker  docker-common docker-selinux docker-engine
#删除
yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-selinux \
                  docker-engine-selinux \
                  docker-engine
#删除配置文件
rm -rf /etc/systemd/system/docker.service.d
rm -rf /var/lib/docker
rm -rf /var/run/docker
```
## 自动安装
### 方法1：安装docker方法
安装软件包：  
```shell
sudo yum install -y yum-utils device-mapper-persistent-data lvm2
```
设置镜像仓库:  
```shell
yum-config-manager --add-repo http://download.docker.com/linux/centos/docker-ce.repo
```
安装docker,输入下面命令，中间可能需要y确认。安装需要一点时间  
```shell
sudo yum install docker-ce
```
安装完成，查看版本  
```shell
docker version
```
docker常用命令  
```shell
systemctl start docker  #启动docker
systemctl enable docker #开机启动docker
systemctl status docker #查看docker状态
systemctl stop docker   #关闭docker
docker version #查看版本
docker run -i -t ubuntu /bin/bash 启动docker 容器
sudo docker ps  获取正在运行的服务
sudo docker exec -it 775c7c9ee1e1 /bin/bash  进入正在运行的服务
```
### 方法2
```shell
curl -sSL https://get.docker.com/ | sh 
```


## 手动安装

### 方法1
#### 1.安装需要的软件包
```shell
sudo yum install -y yum-utils
yum install -y yum-utils device-mapper-persistent-data lvm2
```
#### 2.设置yum源
```shell
yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo
```
#### 3.可以查看所有仓库中所有docker版本，并选择特定版本安装
```shell
yum list docker-ce --showduplicates | sort -r
```
#### 4.安装Docker，命令：yum install docker-ce-版本号，我选的是3:19.03.9-3.ce，如下
```shell
yum install -y https://download.docker.com/linux/centos/7/x86_64/stable/Packages/containerd.io-1.2.6-3.3.el7.x86_64.rpm
yum install docker-ce-cli-19.03.9-3.el7.x86_64
```
### 方法2

#### 1.设置阿里云yum源
```shell
sudo yum install -y yum-utils
yum-config-manager --add-repo http://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

#### 2.查看所有仓库中所有docker版本，并选择特定版本安装
```shell
yum list docker-ce --showduplicates | sort -r
```
#### 3.安装
```shell
yum install -y http://mirrors.aliyun.com/docker-ce/linux/centos/7/x86_64/stable/Packages/containerd.io-1.2.6-3.3.el7.x86_64.rpm
yum install docker-ce-cli-19.03.9-3.el7.x86_64
```

#### 4.设置docker镜像服务器

##### [docker基本使用.md](..\docker\docker基本使用.md) 

启动Docker，命令：systemctl start docker  

```shell
systemctl start docker
```
验证安装是否成功  
```shell
docker version 
```
加入开机启动，如下  
```shell
systemctl enable docker
```
添加docker用户, 并把当前用户添加到docker组内, 是为了当前用户拥有操作docker的权限  
```shell
sudo useradd -m docker
sudo usermod -a -G docker yujing
```
1. 重新加载配置文件
```shell
systemctl reload  docker
```
2. 重启docker
```shell
systemctl restart docker
```