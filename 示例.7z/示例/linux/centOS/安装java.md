# 安装java

## 把yum包更新到最新
```shell
yum update
```
## 一、查看yum源的java包
```shell
yum list java*
```
## 二、安装java1.8 jdk软件
```shell
yum -y install java-1.8.0-openjdk
```
## 三、查看版本，检测是否安装成功
```shell
java -version
rpm -qa |grep java
```
## 四、卸载
先查看 
```shell
rpm -qa | grep java
```
显示如下信息：  
java-1.8.0-openjdk-headless-1.8.0.252.b09-2.el7_8.x86_64  
java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64  
卸载：  
```shell
rpm -e --nodeps java-1.8.0-openjdk-headless-1.8.0.252.b09-2.el7_8.x86_64
rpm -e --nodeps java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64
```
还有一些其他的命令  
```shell
rpm -qa | grep gcj
rpm -qa | grep jdk
```
如果出现找不到openjdk source的话，那么还可以这样卸载  
```shell
 yum -y remove java java-1.8.0-openjdk-headless-1.8.0.252.b09-2.el7_8.x86_64
 yum -y remove java java-1.8.0-openjdk-1.8.0.252.b09-2.el7_8.x86_64
```
