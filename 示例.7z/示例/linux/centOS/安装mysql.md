# 安装mysql

## 清理工作
1.通过rpm -qa | grep mariadb命令查看mariadb的安装包  
2.如果有信息，通过rpm -e --nodeps mariadb-libs-x.x.xx-x.xxx.x86_64命令卸载  

3.通过rpm -qa | grep mysql命令查看mysql的安装包  
4.如果有信息，通过yum remove mysql-community-***命令依次删除（先停止mysql，查看端口，杀死进程）   

5.通过find / -name mysql命令查找mysql配置文件  
6.如果有信息，通过rm -rf 文件路径命令依次删除  

下载  
https://www.mysql.com  
https://dev.mysql.com/downloads/mysql/  
选择Red Hat——rpm-bundle.tar  

## 初始化目录
1.进入虚拟机  
2.通过命mkdir /usr/local/mysql命令创建mysql文件夹  
3.上传上面下载的mysql安装文件到/usr/local/mysql目录  

## 开始安装程序
1.通过tar -xvf mysql-8.0.20-1.el7.x86_64.rpm-bundle.tar命令解压 tar 包。  
2.通过rpm -ivh --nodeps --force mysql-community-common-8.0.20-1.el7.x86_64.rpm命令安装 common。  
3.通过rpm -ivh --nodeps --force mysql-community-libs-8.0.20-1.el7.x86_64.rpm命令安装 libs。  
4.通过rpm -ivh --nodeps --force mysql-community-client-8.0.20-1.el7.x86_64.rpm命令安装 client。  
5.通过rpm -ivh --nodeps --force mysql-community-server-8.0.20-1.el7.x86_64.rpm命令安装 server。  
6.通过rpm -qa | grep mysql命令查看 mysql 的安装包，如果有上面四个信息表示成功。  
7.通过以下命令，完成对mysql数据库的初始化和相关配置：  
输入mysqld --initialize命令，回车。  
输入chown mysql:mysql /var/lib/mysql -R命令，回车。  
输入systemctl start mysqld.service命令，回车。  
输入systemctl status mysqld.service命令，回车，有绿字代表服务启动成功。  
输入systemctl enable mysqld命令，回车。  
8.通过cat /var/log/mysqld.log | grep password命令查看数据库的密码，并复制。  
9.通过mysql -uroot -p命令，回车，进入数据库登陆界面。  
10.粘贴刚刚查到的密码，进行数据库的登陆，mysql的登陆密码也是不显示的。  
11.通过alter user 'root' @'localhost' identified with mysql_native_password by 'root';命令来修改密码。  
12.通过exit命令退出mysql，即可通过新密码root再次登陆。  
13.通过exit命令退出mysql，输入/sbin/iptables -I INPUT -p tcp --dport 3306 -j ACCEPT命令打开防火墙3306端口。  